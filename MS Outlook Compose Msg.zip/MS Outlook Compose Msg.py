import config, webbrowser
from util.TextUtil import TextUtil

if config.pluginContext:
    content = TextUtil.plainTextToUrl(config.pluginContext)
    webbrowser.open("https://outlook.live.com/mail/deeplink/compose?subject=UniqueBible.app&body={0}".format(content))
    # webbrowser.open("https://outlook.com/mail/deeplink/compose?subject=UniqueBible.app&body={0}".format(content))
else:
    webbrowser.open("https://outlook.live.com/mail/deeplink/compose")
