import config, webbrowser
from util.TextUtil import TextUtil

webbrowser.open("https://outlook.live.com/mail/0/inbox")
